# CURE-Rec — ESWA submission package

Submission files for **Expert Systems with Applications** using Elsevier's
\`elsarticle\` class.

## Reviewer-facing files

| File | Purpose |
|---|---|
| \`cure-rec-eswa.tex\` | Double-anonymized main manuscript |
| \`cure-rec-supplementary.tex\` | Double-anonymized supplementary material |
| \`CURE-Rec_Highlights.tex\` | Editable LaTeX highlights file with five compliant bullets |

## Editorial files

| File | Purpose |
|---|---|
| \`cure-rec-title-page.tex\` | Author details, CRediT roles, funding, and competing-interest statement |
| \`cover_letter.tex\` | Identifying cover letter for the editorial office |

## Editable source dependencies

Upload the relevant \`.tex\` files together with:

- \`elsarticle.cls\`
- \`elsarticle-num.bst\`
- \`cure-rec-bibliography.bib\`
- the PDF figure files under \`figures/\`

The PDF outputs are review copies, not substitutes for these editable sources.

## Build

Run:

\`\`\`bash
./build_submission.sh
\`\`\`

The script compiles the main manuscript before the supplement so that
cross-document references resolve, compiles the title page and cover letter,
checks the logs, and removes identifying PDF metadata.

## Editorial Manager checklist

- [ ] Article type: Research Article
- [ ] Upload \`cure-rec-eswa.pdf\` as the anonymized manuscript
- [ ] Upload \`cure-rec-supplementary.pdf\` as anonymized supplementary material
- [ ] Upload \`cure-rec-title-page.pdf\` separately and exclude it from reviewers
- [ ] Upload \`CURE-Rec_Highlights.tex\` as Highlights
- [ ] Upload the editable LaTeX sources, bibliography, class/style, and figures
- [ ] Paste or upload the cover letter
- [ ] Supply an anonymized repository link for code and result artifacts
- [ ] Add any remaining co-author ORCID iDs and the corresponding-author telephone number
- [ ] Verify that the title-page file is excluded from the reviewer PDF

## Anonymity notes

- The reviewer manuscript and supplement contain no author names, affiliations,
  institutional email addresses, or identifying repository URL.
- CRediT roles, funding, competing interests, and acknowledgments are isolated
  in the title-page file.
- The public repository URL should be restored only in the accepted manuscript.
