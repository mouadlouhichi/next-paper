#!/usr/bin/env bash
set -euo pipefail

latexmk -pdf -interaction=nonstopmode -file-line-error cure-rec-eswa.tex
latexmk -pdf -interaction=nonstopmode -file-line-error cure-rec-supplementary.tex
latexmk -pdf -interaction=nonstopmode -file-line-error cure-rec-title-page.tex
latexmk -pdf -interaction=nonstopmode -file-line-error CURE-Rec_Highlights.tex
latexmk -pdf -interaction=nonstopmode -file-line-error cover_letter.tex

python3 - <<'PY'
from pathlib import Path
from pypdf import PdfReader, PdfWriter

for name in (
    "cure-rec-eswa.pdf",
    "cure-rec-supplementary.pdf",
    "cure-rec-title-page.pdf",
    "CURE-Rec_Highlights.pdf",
    "cover_letter.pdf",
):
    source = Path(name)
    reader = PdfReader(source)
    writer = PdfWriter()
    writer.clone_document_from_reader(reader)
    writer.metadata = {
        "/Author": "",
        "/Creator": "",
        "/Producer": "",
        "/Subject": "",
        "/Keywords": "",
        "/Title": "",
    }
    temporary = source.with_suffix(".sanitized.pdf")
    with temporary.open("wb") as stream:
        writer.write(stream)
    temporary.replace(source)
PY

if rg -n '(^!|LaTeX Warning|Package .* Warning|Class .* Warning|Overfull|Underfull|undefined|multiply defined)' \
  cure-rec-eswa.log cure-rec-supplementary.log cure-rec-title-page.log CURE-Rec_Highlights.log cover_letter.log; then
  exit 1
fi

lacheck cure-rec-eswa.tex
lacheck cure-rec-supplementary.tex
lacheck cure-rec-title-page.tex
lacheck CURE-Rec_Highlights.tex
lacheck cover_letter.tex