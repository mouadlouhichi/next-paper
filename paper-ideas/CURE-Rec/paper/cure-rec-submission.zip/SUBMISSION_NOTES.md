# CURE-Rec submission package — round-2 revision

Manuscript: `cure-rec.tex` (Springer Nature `sn-jnl` class, math/physical-sciences
numbered reference style). Build with `./build_clean.sh` (full TeX Live / MacTeX)
or `tectonic cure-rec.tex`.

## What changed in this revision (reviewer round 2)

New experiments executed and archived (see `code/results/reviewer_phase_assets/`
in the repository, with SHA256SUMS):

1. Held-out selector comparison on two predeclared divergent configurations
   (lhs-012, lhs-009): exact CURE best in 20/20 held-out evaluation seeds in both.
2. Utility-weight sensitivity (14 predeclared vectors) and constraint-frontier
   phase diagram (135 combinations).
3. Semi-real integration: BPR-MF trained on simulator-logged feedback deployed as
   the base policy; decision consistent with the hand-crafted game.
4. Integrated scalability n=8 with four new operators implemented as real slate
   transformations (7,505 s, 114 MB, zero Shapley efficiency gap, regret 0).
5. MovieLens-1M user-level paired inference (executed externally): McNemar,
   paired bootstrap, permutation tests, Holm correction; all four model x metric
   comparisons significant.

Manuscript fixes: formal c(S)/no-op semantics, Gini definition, scenario
coefficient table, Appendix F time indexing, casewise selection rule, Algorithms
1-2 completed, memory complexity, BPR/SASRec losses and search spaces, references
[11][21][27][31][41] corrected and 2024 literature added, LHS mode/status wording,
grand-coalition table semantics, Responsible AI statement, validity structure,
abstract/conclusion rewrites.

Optional remaining runs (notebook `code/notebooks/13_reviewer_closure_runs.ipynb`):
integrated n=10 game and Amazon second-domain audit.
