#!/usr/bin/env bash
# Clean deterministic Springer build. Run from any directory.
set -euo pipefail
cd "$(dirname "$0")"
rm -f cure-rec.aux cure-rec.bbl cure-rec.blg cure-rec.log cure-rec.out cure-rec.toc cure-rec.pdf
pdflatex -interaction=nonstopmode -halt-on-error cure-rec.tex
bibtex cure-rec
pdflatex -interaction=nonstopmode -halt-on-error cure-rec.tex
pdflatex -interaction=nonstopmode -halt-on-error cure-rec.tex
# Fail the build if unresolved publication artifacts or width violations remain.
if grep -Eq 'Table \?\?|\?\?\?|There were undefined references|Reference .* undefined|Citation .* undefined|multiply defined|Overfull \\hbox|Overfull \\vbox' cure-rec.log cure-rec.blg; then
  echo 'Unresolved reference, duplicate label, or overfull box found in build logs' >&2
  exit 1
fi
echo "Built $(pwd)/cure-rec.pdf"
