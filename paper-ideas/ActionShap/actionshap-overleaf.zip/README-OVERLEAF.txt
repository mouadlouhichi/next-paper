ActionShap -- ACM TORS review copy (Overleaf project)
======================================================

Generated from the repository at commit 1f316f0 on 2026-09-14 by
`make overleaf`. Result manifest quoted by both documents: 43a608fd74a9.
Re-run `make overleaf` after any change to a .tex, a table or a figure: this project is a
snapshot, and a snapshot that is compiled and downloaded is indistinguishable from a
current one unless the stamp below says otherwise.

Menu -> Settings
  * Main document: acmmanuscript.tex, then switch to supplementary.tex and compile again
    for the second PDF. Both share tables/ and figures/.
  * Compiler: pdfLaTeX, TeX Live 2024 or newer.

Class options as generated: manuscript,screen,review,anonymous (and the supplement's).
`anonymous` is what a double-blind review copy needs. Drop it only at camera-ready: the
running head and the CRediT paragraph follow it through the \ifreviewcopy switch in each
preamble, so the author names return with no other edit.

No .bbl is shipped on purpose: the repository copy predates the current text, and a
present-but-stale .bbl lets latexmk skip BibTeX. The bibliography comes from
actionshap-bibliography.bib with ACM-Reference-Format.bst, which are both in this zip.

No compiled PDF is shipped. When you download the two, overwrite
paper-ideas/ActionShap/acmart-primary/acmmanuscript.pdf and .../supplementary.pdf at those
exact paths -- not beside them -- then run `make ready` in the repository. It reads the
compiled text (anonymised title page, the manifest stamp 43a608fd74a9,
the review-9 panels, no placeholder sentences) and recomputes the deposit's checksums, and
it exits non-zero with the blockers it found.
